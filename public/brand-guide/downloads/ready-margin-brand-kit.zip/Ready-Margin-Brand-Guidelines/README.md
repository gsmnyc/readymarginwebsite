# Ready Margin — Brand Guidelines

Studio edition 01 · September 2026 · Version 1.0

## Open the website

Open `website/index.html` in a browser. The site and font work offline. To enable clipboard copying in browsers that require a secure origin, serve the `website` directory on localhost; otherwise copy the printed HEX values. All downloadable assets are included locally.

The Next.js version is available at `/brand-guidelines`. Its source is in `source/nextjs`. The guidelines use their own visual system and retain the restaurant website's existing pages.

## Edit in Figma

The native editable design is at https://www.figma.com/design/tDTgaoHi6WTJfwaiPLYpyR?node-id=3-157

The file contains ten brand guideline boards and the editable website layout, with native text, vector logos, reusable specimens, 78 variables and six type styles. The ZIP includes individual SVG boards and a local Figma builder plugin as a portable backup of the ten guideline boards. SVG boards can be imported into a Design file; use the builder plugin to recreate native text and token bindings. To download a native `.fig` copy, open the linked project and choose File → Save local copy.

To use the builder: in Figma desktop, Plugins → Development → Import plugin from manifest → select `figma/manifest.json`, then run “Ready Margin Brand Guidelines”. It creates the system in the current file; use a fresh Design file. A second run detects the existing named page and stops to prevent duplicate boards.

## Contents

- `guidelines/ready-margin-guidelines.pdf`: a shareable, vector guideline document.
- `logos/`: exactly three essential SVG files: primary, reverse and one-color.
- `tokens/`: machine-readable JSON, CSS variables and screen RGB / approximate print CMYK references.
- `figma/`: project link, editable SVG artboards and the native builder source.
- `website/`: responsive, standalone website with bundled assets and no installation required.
- `source/`: the React/Next.js guidelines source and content.
- `font/`: the existing Plus Jakarta Sans font and its SIL Open Font License.

## System rules

The original ink (#222222), paper (#F4F1E8), gold (#E7C14B), structural gray (#D5D5CC) and muted text (#596058) remain the foundation. Five six-tone palettes extend that system. Functional status colors communicate confirmed work, required attention and errors; never rely on color alone.

The 60/25/10/5 ratio is a starting point for everyday brand compositions, not a compulsory ratio for every layout. Supporting campaign panels may use a single family. Use ink text on gold. The documented text pairs meet a 4.5:1 minimum for body text, calculated from the supplied sRGB HEX values. CMYK figures are approximate arithmetic conversions, not a color-managed print specification; agree the printing profile and proof with your production supplier.

The logo has one role and three practical production versions. Unnecessary wordmark-only, symbol-only, label, badge and badgeXL categories are intentionally absent from this deliverable. Original production website assets remain in the repository because existing pages use them.

Charts and applications are illustrative design templates, not client results or financial claims. No stock photography or new image license is required by this kit.
