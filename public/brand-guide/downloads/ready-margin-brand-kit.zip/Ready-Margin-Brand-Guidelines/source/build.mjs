import {build} from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
await build({entryPoints:['website-entry.tsx'],outfile:'../website/app.js',bundle:true,minify:true,format:'iife',jsx:'automatic',platform:'browser',define:{'process.env.NODE_ENV':'"production"'},alias:{'@':path.resolve('nextjs')},external:['/brand-guide/*']});
let css=await fs.readFile('../website/app.css','utf8');
css='*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0}button,a{touch-action:manipulation}button{cursor:pointer}'+css.replaceAll('/brand-guide/PlusJakartaSans-variable.woff2','./assets/PlusJakartaSans-variable.woff2');
await fs.writeFile('../website/app.css',css);
