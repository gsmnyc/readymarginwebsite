"use client";

/* eslint-disable @next/next/no-img-element */
import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import { brandGuidelines as data, contrastRatio, swatchText } from "@/lib/brand-guidelines";
import "./guide.css";

const sections = [
  ["overview", "The brand"], ["logo", "Logo use"], ["color", "Color system"],
  ["typography", "Typography"], ["voice", "Our voice"], ["applications", "In practice"],
  ["downloads", "The toolkit"],
] as const;

function Arrow({ down = false }: { down?: boolean }) {
  return <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none"><path d={down ? "M12 4v15m-6-6 6 6 6-6M5 22h14" : "M5 19 19 5M5 5h14v14"} stroke="currentColor" strokeWidth="1.5" /></svg>;
}

function SectionTitle({ number, title, children }: { number: string; title: string; children: ReactNode }) {
  return <div className="bg-section-heading"><span className="bg-index">{number} /</span><div><h2>{title}</h2><p>{children}</p></div></div>;
}

export function BrandGuide({ assetRoot = "/brand-guide", downloadRoot = "/brand-guide/downloads", portable = false }: { assetRoot?: string; downloadRoot?: string; portable?: boolean }) {
  const [active, setActive] = useState("overview");
  const [menu, setMenu] = useState(false);
  const [copied, setCopied] = useState("");
  const [copyFailed, setCopyFailed] = useState(false);
  const [logoSurface, setLogoSurface] = useState("Paper");
  const [composition, setComposition] = useState("signature");
  const [weight, setWeight] = useState(600);
  const selected = data.compositions.find((item) => item.id === composition)!;
  const logo = `${assetRoot}/ready-margin${logoSurface === "Ink" ? "-reverse" : ""}.svg`;
  const kitUrl = `${downloadRoot}/${portable ? "ready-margin-assets.zip" : "ready-margin-brand-kit.zip"}`;

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
      if (visible[0]) setActive(visible[0].target.id);
    }, { rootMargin: "-10% 0px -55% 0px", threshold: 0 });
    document.querySelectorAll(".bg-guide section[id]").forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!copied) return;
    const timer = window.setTimeout(() => setCopied(""), 2200);
    return () => window.clearTimeout(timer);
  }, [copied]);

  async function copy(hex: string) {
    try {
      await navigator.clipboard.writeText(hex);
      setCopyFailed(false);
      setCopied(hex);
    } catch {
      setCopyFailed(true);
      setCopied(hex);
    }
  }

  return <div className="bg-guide">
    <aside className="bg-sidebar">
      <a className="bg-brand" href="#overview" aria-label="Ready Margin brand guidelines"><img src={`${assetRoot}/ready-margin.svg`} alt="Ready Margin" width="182" height="30" /></a>
      <div className="bg-sidebar-label">Brand guidelines<br /><span>Studio edition / 01</span></div>
      <button className="bg-mobile-toggle" onClick={() => setMenu(!menu)} aria-expanded={menu} aria-controls="bg-navigation">Contents <span>{menu ? "−" : "+"}</span></button>
      <nav id="bg-navigation" aria-label="Brand guideline sections" className={menu ? "bg-nav bg-nav-open" : "bg-nav"}>
        {sections.map(([id, title], i) => <a key={id} href={`#${id}`} className={active === id ? "is-active" : ""} aria-current={active === id ? "location" : undefined} onClick={() => { setActive(id); setMenu(false); }}><span>{String(i + 1).padStart(2, "0")}</span>{title}<span className="bg-nav-dot" /></a>)}
      </nav>
      <div className="bg-sidebar-bottom"><a className="bg-sidebar-download" href={kitUrl} download>{portable ? "Download brand assets" : "Download brand kit"} <Arrow down /></a><p>Made for the work behind<br />a well-run restaurant.</p><span>© Ready Margin · {data.date}</span></div>
    </aside>

    <main id="main" className="bg-main">
      <div className="bg-topbar"><span>A little clarity goes a long way.</span><a href="#downloads">Get the assets <Arrow /></a></div>

      <section id="overview" className="bg-overview">
        <div className="bg-eyebrow"><span className="bg-status-dot" /> THE READY MARGIN BRAND <span className="bg-edition">GUIDELINES / V{data.version}</span></div>
        <h1>Make room for<br />what <span>matters.</span></h1>
        <div className="bg-intro"><p>Clear numbers. Calmer operations.<br />More time for the restaurant.</p><p>This is how Ready Margin shows up. A considered system for building a brand that feels as capable, clear and human as the work we do.</p></div>
        <div className="bg-hero-poster">
          <div className="bg-poster-top"><img src={`${assetRoot}/ready-margin.svg`} alt="Ready Margin" width="172" height="28" /><span>BUILT FOR RESTAURANTS.</span></div>
          <div className="bg-poster-headline">Less back office.<br />More front of house<span>.</span></div>
          <div className="bg-poster-bottom"><span>You focus on the restaurant.<br />We handle the work behind it.</span><div className="bg-poster-squares" aria-hidden="true"><i /><i /><i /></div><span>READY FOR<br />WHAT’S NEXT. ↗</span></div>
        </div>
        <div className="bg-principles"><article><span>01 — OUR ROLE</span><h3>Quietly capable.</h3><p>{data.positioning}</p></article><article><span>02 — OUR APPROACH</span><h3>Clarity first.</h3><p>Turn the work behind the scenes into clear records, named responsibilities and useful next steps.</p></article><article><span>03 — OUR CHARACTER</span><h3>Always human.</h3><p>Warm, grounded and practical. We understand there’s a real service on the other side of every number.</p></article></div>
      </section>

      <section id="logo" className="bg-section">
        <SectionTitle number="02" title="One logo. Used well.">A recognisable signature, with enough room to breathe. Keep it simple and consistent.</SectionTitle>
        <div className="bg-specimen-bar"><span>THE PRIMARY LOGO</span><div className="bg-segmented" role="group" aria-label="Logo background">{["Paper", "Ink", "Gold"].map((surface) => <button key={surface} aria-pressed={logoSurface === surface} onClick={() => setLogoSurface(surface)}>{surface}</button>)}</div></div>
        <div className={`bg-logo-stage bg-logo-${logoSurface.toLowerCase()}`}><div className="bg-logo-clearspace"><img src={logo} alt={`Ready Margin logo on ${logoSurface.toLowerCase()}`} width="500" height="81" /><span className="bg-clearspace-note">MINIMUM CLEAR SPACE = ½ LOGO HEIGHT</span></div></div>
        <div className="bg-caption-row"><span>Use the supplied vector artwork. Never retype or redraw it.</span><a href={logo} download>Download this logo <Arrow down /></a></div>
        <div className="bg-rules-grid"><article><span className="bg-small-label">GIVE IT SPACE</span><h3>Let the signature stand.</h3><p>Keep at least half the full logo height clear on every side. Use a minimum display width of 140 px, or 35 mm in print.</p></article><article><span className="bg-small-label">KEEP IT LEGIBLE</span><h3>Choose a quiet surface.</h3><p>Use the primary logo on paper or gold. Use the reverse logo on ink, deep forest or midnight. Use the one-color file for single-ink production.</p></article><article><span className="bg-small-label">PROTECT THE ARTWORK</span><h3>No extra treatments.</h3><p>Keep the original proportions and colors. Avoid shadows, outlines, rotation, busy photography and decorative containers.</p></article></div>
      </section>

      <section id="color" className="bg-section">
        <SectionTitle number="03" title="A little warmth. A lot of range.">Our core stays familiar. Supporting palettes give the brand room to work across stories, reports and everyday communication.</SectionTitle>
        <div className="bg-core-swatches">{[{name:"Paper",hex:"#F4F1E8",role:"The breathing room"},{name:"Ink",hex:"#222222",role:"The clarity"},{name:"Ready gold",hex:"#E7C14B",role:"The signature"}].map((color) => <button key={color.name} className="bg-core-swatch" style={{background:color.hex,color:swatchText(color.hex)}} onClick={() => copy(color.hex)} aria-label={`Copy ${color.name} ${color.hex}`}><span>{color.role}<span>↗</span></span><div><h3>{color.name}</h3><span>{color.hex} <small>{copied === color.hex && !copyFailed ? "Copied ✓" : "Click to copy"}</small></span></div></button>)}</div>
        <div className="bg-color-ratio"><div className="bg-ratio-strip"><i style={{background:"#F4F1E8",flex:60}} /><i style={{background:"#222222",flex:25}} /><i style={{background:"#E7C14B",flex:10}} /><i style={{background:"#AFCAA8",flex:5}} /></div><p><strong>Start with 60 / 25 / 10 / 5.</strong> Paper 60%, ink 25%, gold 10%, one supporting accent 5%. A starting point for everyday compositions; campaign panels may use a single supporting palette.</p></div>
        <div className="bg-subheading"><h3>The expanded palette</h3><p>Five families. Six tones each. Click any swatch to copy its HEX.</p></div>
        <div className="bg-palette-families">{data.palettes.map((family) => <div className="bg-palette-family" key={family.id}><div className="bg-family-description"><h4>{family.name}</h4><p>{family.role}</p></div><div className="bg-ramp">{family.colors.map((color) => <button key={color.step} onClick={() => copy(color.hex)} className="bg-ramp-color" aria-label={`Copy ${color.name} ${color.hex}`}><div style={{background:color.hex,color:swatchText(color.hex)}}><span>{color.step}</span><span>{copied === color.hex && !copyFailed ? "✓" : "+"}</span></div><span>{color.name}</span><code>{color.hex}</code></button>)}</div></div>)}</div>
        <div className="bg-composition-lab"><div className="bg-subheading"><h3>Built to work together</h3><p>Choose a palette to see a considered composition.</p></div><div className="bg-composition-tabs" role="group" aria-label="Composition palette">{data.compositions.map((item) => <button key={item.id} onClick={() => setComposition(item.id)} aria-pressed={composition === item.id}><span style={{background:item.colors[0],borderColor:item.colors[1]}} />{item.name}</button>)}</div><div className="bg-composition-preview" style={{"--composition-bg":selected.background,"--composition-fg":selected.foreground,"--composition-accent":selected.accent} as CSSProperties}><div className="bg-composition-copy"><span>READY MARGIN / {selected.name.toUpperCase()}</span><h3>Good work.<br />Clearer numbers.</h3><p>{selected.note}</p><span className="bg-preview-cta">Make room for what matters <Arrow /></span></div><div className="bg-composition-art" aria-hidden="true"><div /><div /><div /><div /><div /></div></div><div className="bg-composition-colors">{selected.colors.map((color) => <button key={color} onClick={() => copy(color)} aria-label={`Copy composition color ${color}`}><i style={{background:color}} /><code>{color}</code></button>)}</div></div>
        <div className="bg-subheading"><h3>Color with a purpose</h3><p>Status colors are functional. Always pair them with words or an icon.</p></div>
        <div className="bg-semantic-grid">{data.semantic.map((color) => <article key={color.id} style={{background:color.background}}><span style={{color:color.hex}}><i style={{background:color.hex}} />{color.name}</span><p>{color.use}</p><code>{color.hex}</code></article>)}</div>
        <div className="bg-accessibility"><div><span className="bg-small-label">READABILITY IS PART OF THE BRAND</span><h3>Good contrast.<br />Every time.</h3><p>Use a contrast ratio of at least 4.5:1 for body text and 3:1 for large text and meaningful interface graphics. Gold needs ink text.</p></div><div className="bg-contrast-list">{[{fg:"#222222",bg:"#F4F1E8",name:"Ink on paper"},{fg:"#222222",bg:"#E7C14B",name:"Ink on gold"},{fg:"#F4F1E8",bg:"#203D2C",name:"Paper on deep forest"},{fg:"#613B2B",bg:"#EFD9CA",name:"Burnt earth on blush"},{fg:"#EDF2F4",bg:"#293F50",name:"Cloud on midnight"}].map((pair) => <div key={pair.name}><span className="bg-aa-sample" style={{color:pair.fg,background:pair.bg}}>Aa</span><span>{pair.name}</span><code>{contrastRatio(pair.fg,pair.bg).toFixed(2)}:1</code><span className="bg-pass">AA ✓</span></div>)}<p>Avoid paper or white body text on gold. Screen HEX/RGB values are the source of truth; proof print colors with the production supplier.</p></div></div>
      </section>

      <section id="typography" className="bg-section">
        <SectionTitle number="04" title="Say it clearly.">One type family. A useful range of weights. Plus Jakarta Sans brings precision with a human edge.</SectionTitle>
        <div className="bg-type-specimen"><div className="bg-specimen-bar"><span>PLUS JAKARTA SANS</span><div className="bg-segmented" role="group" aria-label="Type specimen weight">{[{value:400,label:"Regular"},{value:500,label:"Medium"},{value:600,label:"Semibold"}].map((item) => <button key={item.value} aria-pressed={weight === item.value} onClick={() => setWeight(item.value)}>{item.label}</button>)}</div></div><div className="bg-type-large" style={{fontWeight:weight}}>Aa Bb Cc<span>Good things happen<br />with a little clarity.</span></div><div className="bg-type-glyphs">ABCDEFGHIJKLMNOPQRSTUVWXYZ<br />abcdefghijklmnopqrstuvwxyz<br />0123456789 &amp; @ % + − = / ? !</div></div>
        <div className="bg-type-table" role="table" aria-label="Desktop typography scale"><div className="bg-type-table-head" role="row"><span role="columnheader">Role / desktop</span><span role="columnheader">Size / line</span><span role="columnheader">Weight</span><span role="columnheader">Use</span></div>{data.typeScale.map((type) => <div role="row" key={type.role}><span role="cell">{type.role}</span><code role="cell">{type.size} / {type.line} px</code><span role="cell">{type.weight}</span><span role="cell">{type.use}</span></div>)}</div>
        <div className="bg-rules-grid"><article><span className="bg-small-label">HIERARCHY</span><h3>Less is clearer.</h3><p>Use semibold for headlines, regular for body and medium for captions. Keep headlines short and paragraphs to about 45–70 characters per line.</p></article><article><span className="bg-small-label">SMALLER SCREENS</span><h3>Scale with care.</h3><p>On mobile, use 44/48 px display, 36/40 px page titles and 28/34 px section headings. Keep body text at 16/26 px.</p></article><article><span className="bg-small-label">NUMBERS &amp; ACCESS</span><h3>Make the details count.</h3><p>Use tabular numbers in financial tables. Keep meaning in sentence case. The typeface uses the SIL Open Font License; the license ships with the kit.</p></article></div>
      </section>

      <section id="voice" className="bg-section">
        <SectionTitle number="05" title="Sound like a person. A capable one.">Write to someone who has a restaurant to run. Be clear about the work, warm about the people and honest about the scope.</SectionTitle>
        <div className="bg-voice-list">{data.voice.map((principle,i) => <article key={principle.title}><div className="bg-voice-intro"><span className="bg-small-label">0{i+1}</span><h3>{principle.title}</h3><p>{principle.description}</p></div><div className="bg-voice-examples"><div className="bg-voice-before"><span>AVOID</span><p>{principle.before}</p></div><div className="bg-voice-after"><span>WRITE LIKE THIS</span><p>{principle.after}</p></div></div></article>)}</div>
        <div className="bg-language-note"><span>THE WRITING CHECK</span><p>Can someone understand the work, who owns it and what happens next? If so, it sounds like Ready Margin.</p></div>
      </section>

      <section id="applications" className="bg-section">
        <SectionTitle number="06" title="Made for the real world.">The same clear character, wherever we show up. Use these compositions as starting points, then adapt the content.</SectionTitle>
        <div className="bg-applications"><article className="bg-app-social"><div className="bg-social-art"><img src={`${assetRoot}/ready-margin-reverse.svg`} alt="Ready Margin" width="175" height="29" /><span>FOR THE WORK<br />BEHIND THE WORK.</span><h3>A clearer close.<br />A calmer<br />tomorrow<span>.</span></h3><div className="bg-social-foot">RESTAURANT FINANCE &amp; OPERATIONS <Arrow /></div></div><div className="bg-application-caption"><h4>Social &amp; campaigns</h4><p>One thought. Strong type. A quiet supporting palette.</p></div></article><article className="bg-app-report"><div className="bg-report-art"><div className="bg-report-page"><img src={`${assetRoot}/ready-margin.svg`} alt="Ready Margin" width="145" height="24" /><span className="bg-report-eyebrow">ILLUSTRATIVE TEMPLATE / MONTHLY REVIEW</span><h3>A clearer view<br />of the month.</h3><p>Restaurant finance &amp; operations</p><div className="bg-report-chart" aria-hidden="true">{[35,52,46,68,60,79,88].map((height,i) => <i key={i} style={{height:`${height}%`}} />)}</div><div className="bg-report-bottom"><span>THE NUMBERS. THE CONTEXT. THE NEXT STEP.</span><span>01</span></div></div></div><div className="bg-application-caption"><h4>Reports &amp; documents</h4><p>Paper, ink and gold. Structure that makes room for the detail.</p></div></article><article className="bg-app-card"><div className="bg-card-art"><div className="bg-business-card"><img src={`${assetRoot}/ready-margin.svg`} alt="Ready Margin" width="195" height="32" /><p>Good work.<br />Clearer numbers.</p><span>readymargin.com ↗</span></div></div><div className="bg-application-caption"><h4>Everyday essentials</h4><p>The signature palette. Generous space. Only what matters.</p></div></article><article className="bg-app-editorial"><div className="bg-editorial-art"><span>READY MARGIN / A USEFUL PERSPECTIVE</span><h3>More time<br />at the table.</h3><p>You focus on the restaurant.<br />We handle the work behind it.</p><div className="bg-editorial-line" aria-hidden="true"><i /><i /><i /></div></div><div className="bg-application-caption"><h4>Editorial &amp; stories</h4><p>A warmer palette for the people behind the restaurant.</p></div></article></div>
        <div className="bg-rules-grid"><article><span className="bg-small-label">LAYOUT</span><h3>Give the work room.</h3><p>Use an 8 px spacing rhythm. Start with 64 px desktop margins and 24 px on mobile. Align to a clear grid; avoid decorative clutter.</p></article><article><span className="bg-small-label">IMAGERY</span><h3>Show the working day.</h3><p>Choose natural light, honest environments and people doing real work. Use charcoal, timber and warm neutral tones. Avoid staged celebrations and stock finance clichés.</p></article><article><span className="bg-small-label">DATA &amp; MOTION</span><h3>Clarity over spectacle.</h3><p>Label charts directly and use a second cue beyond color. Keep motion brief and purposeful; respect reduced-motion preferences. Example charts are illustrative.</p></article></div>
      </section>

      <section id="downloads" className="bg-section bg-downloads">
        <div><span className="bg-small-label">07 / THE TOOLKIT</span><h2>Everything you need.<br />Nothing you don’t.</h2><p>{portable ? "The guidelines, essential logo files, color tokens and editable layouts. Everything you need to put the brand to work." : "The guidelines, essential logo files, color tokens, editable layouts and a standalone website. All in one considered kit."}</p><a className="bg-download-button" href={kitUrl} download>{portable ? "Download the brand assets" : "Download the complete kit"} <Arrow down /></a></div>
        <div className="bg-download-list">{[{name:"Brand guidelines",detail:"PDF · Ready to read and share",file:"ready-margin-guidelines.pdf"},{name:"Essential logo files",detail:"SVG · Primary, reverse & one-color",file:"ready-margin-logos.zip"},{name:"Design tokens",detail:"JSON · Color, type & spacing",file:"ready-margin-tokens.json"},{name:"Editable Figma project",detail:"Native layers · Variables & specimens",url:"https://www.figma.com/design/tDTgaoHi6WTJfwaiPLYpyR"}].map((item) => <a key={item.name} href={item.url || `${downloadRoot}/${item.file}`} download={item.file ? true : undefined} target={item.url ? "_blank" : undefined} rel={item.url ? "noreferrer" : undefined}><div><h3>{item.name}</h3><span>{item.detail}</span></div><Arrow down={!item.url} /></a>)}</div>
      </section>
      <footer className="bg-footer"><img src={`${assetRoot}/ready-margin.svg`} alt="Ready Margin" width="145" height="24" /><span>Clarity for the work behind it.</span><span>BRAND GUIDELINES / {data.date.toUpperCase()}</span><a href="#overview" aria-label="Back to top">↑</a></footer>
    </main>
    <div className={`bg-toast ${copied ? "bg-toast-visible" : ""}`} role="status" aria-live="polite">{copyFailed ? `Copy manually: ${copied}` : `${copied} copied to clipboard`}</div>
  </div>;
}
