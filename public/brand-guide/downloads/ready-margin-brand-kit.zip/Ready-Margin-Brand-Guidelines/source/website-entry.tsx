import { createRoot } from "react-dom/client";
import { BrandGuide } from "./nextjs/app/brand-guidelines/guide";

createRoot(document.getElementById("root")!).render(<BrandGuide assetRoot="./assets" downloadRoot="./downloads" portable />);
